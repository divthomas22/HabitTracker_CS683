Your source code should be stored in this folder. 
Please give a brief description about your source code structure here.
