package com.example.habittracker

data class Habit(val id : Int, var name : String, var description : String,
                 var priority : Float, var remindTime : String)
